# Zyvo Programming Language - Compiler Lab Project Report

## 1. Introduction

Zyvo is a simple custom programming language designed for the Compiler Lab course.
It replaces conventional keywords and function names with its own vocabulary: for
example `Joggo` performs addition and `Biyano` performs subtraction. The project
shows how a language can have its own vocabulary and how a language processor turns
source text into results.

## 2. Objectives and how they are met

| Objective (from the proposal) | Where it is met |
|---|---|
| Design a custom language with a unique name | Zyvo - sections 3 and 4 |
| Define at least 25 custom function names | 30 commands, section 4 |
| Assign a specific operation to each function | `src/functions.hpp`, `src/interpreter.hpp` |
| Function table with names, purposes and examples | Section 4 (also `zyvo --table`) |
| A basic compiler / interpreter | C++17 interpreter in `src/` |
| Lexical analysis, syntax analysis, execution | Sections 5-8 (plus semantic analysis) |

## 3. Language overview

Zyvo uses a function-based syntax. Variables are created with `ManDao` and are written
without quotes, exactly as in the proposal:

```
manDao(a, 10)
manDao(b, 5)
manDao(result, joggo(a, b))
dekhao(result)        # output: 15
```

Two commands control the flow of a program and take a block in braces:

```
jodi(condition) { ... } nahole { ... }     # if / else  (nahole is optional)
ghuro(condition) { ... }                   # loop while the condition is true
```

Rules: function names are not case-sensitive; text uses double quotes; numbers may be
integers or decimals; `true` and `false` are the logical values; `#` or `//` start a comment.
`nahole` ("otherwise") is the only word that is not one of the 30 commands.

## 4. Function table (30 commands)

| # | Zyvo | Standard operation | Purpose | Example |
|---|------|--------------------|---------|---------|
| 1 | `Joggo` | Add / Sum | Add two numbers | `Joggo(4, 2)  -> 6` |
| 2 | `Biyano` | Subtract | Subtract two numbers | `Biyano(4, 2) -> 2` |
| 3 | `Gunon` | Multiply | Multiply two numbers | `Gunon(4, 2)  -> 8` |
| 4 | `Vaggo` | Divide | Divide two numbers | `Vaggo(9, 2)  -> 4.5` |
| 5 | `Vagsesh` | Modulus | Find the remainder | `Vagsesh(9, 2) -> 1` |
| 6 | `Borok` | Greater Than | Is the first number greater? | `Borok(4, 2)       -> true` |
| 7 | `Chotok` | Less Than | Is the first number smaller? | `Chotok(4, 2)      -> false` |
| 8 | `Somotul` | Equal | Check equality of two values | `Somotul(3, 3)     -> true` |
| 9 | `Osomot` | Not Equal | Check inequality of two values | `Osomot(3, 4)      -> true` |
| 10 | `BoroSoman` | Greater Than or Equal | Greater than or equal? | `BoroSoman(4, 4)   -> true` |
| 11 | `ChotoSoman` | Less Than or Equal | Less than or equal? | `ChotoSoman(3, 4)  -> true` |
| 12 | `Ebong` | Logical AND | True if both conditions are true | `Ebong(true, false)  -> false` |
| 13 | `Othoba` | Logical OR | True if at least one condition is true | `Othoba(true, false) -> true` |
| 14 | `Naaki` | Logical NOT | Reverse a logical value | `Naaki(true)         -> false` |
| 15 | `Dekhao` | Print / Output | Display one or more values | `Dekhao("Sum =", x)` |
| 16 | `Dhoro` | Input | Read a line from the user into a variable | `Dhoro(age, "Age? ")` |
| 17 | `ManDao` | Assign | Assign a value to a variable | `ManDao(x, 10)` |
| 18 | `ManPao` | Get Variable | Retrieve a variable's value | `ManPao(x)  -> 10` |
| 19 | `Baraw` | Increment | Increase a numeric variable by one | `Baraw(x)   (10 -> 11)` |
| 20 | `Komaw` | Decrement | Decrease a numeric variable by one | `Komaw(x)   (11 -> 10)` |
| 21 | `Borgo` | Square | Calculate the square of a number | `Borgo(5)     -> 25` |
| 22 | `Ghono` | Cube | Calculate the cube of a number | `Ghono(3)     -> 27` |
| 23 | `Borgomul` | Square Root | Find the square root | `Borgomul(81) -> 9` |
| 24 | `Porom` | Absolute Value | Return the absolute value | `Porom(-7)    -> 7` |
| 25 | `Jora` | String Concatenation | Join two values into text | `Jora("Zy", "vo") -> Zyvo` |
| 26 | `Doirgho` | String Length | Count characters in a string | `Doirgho("Zyvo")   -> 4` |
| 27 | `Ulto` | Reverse String | Reverse a string | `Ulto("abc")       -> cba` |
| 28 | `Barbar` | Repeat String | Repeat a string several times | `Barbar("Hi", 3)   -> HiHiHi` |
| 29 | `Jodi` | Conditional Statement | Run a block only if a condition is true (optional 'nahole' else-block) | `Jodi(Borok(a, b)) { ... } nahole { ... }` |
| 30 | `Ghuro` | Loop | Repeat a block while a condition is true | `Ghuro(Chotok(i, 5)) { ... }` |

Notes: `Jodi` and `Ghuro` are block statements. `ManDao`, `ManPao`, `Baraw`, `Komaw` and
`Dhoro` take a variable name as their first argument. `Dhoro(x, "prompt")` reads a line
into `x` (it becomes a number if the text is numeric). `Dekhao` accepts any number of values.

## 5. Architecture

```
source (.zy) -> LEXER -> tokens -> PARSER -> syntax tree (AST)
             -> SEMANTIC ANALYSER -> checked AST -> INTERPRETER -> output
```

| File | Phase / role |
|---|---|
| `src/lexer.hpp` | Phase 1 - lexical analysis |
| `src/parser.hpp`, `src/ast.hpp` | Phase 2 - syntax analysis, syntax tree |
| `src/semantic.hpp` | Phase 3 - semantic analysis |
| `src/interpreter.hpp` | Phase 4 - execution |
| `src/functions.hpp` | the function table: names, signatures, descriptions |
| `src/main.cpp` | command line, error display |

## 6. Phase 1 - Lexical analysis

The lexer reads characters and produces tokens with line and column numbers. Token types:
`IDENT`, `NUMBER`, `STRING`, `TRUE`, `FALSE`, `ELSE`, `LPAREN`, `RPAREN`, `LBRACE`, `RBRACE`,
`COMMA`, `END`. Whitespace and comments are skipped. Lexical errors: unexpected character,
unclosed string, unknown escape sequence, malformed number (`12abc`, `1.2.3`).

Sample program and its tokens (`zyvo prog.zy --tokens`):

```
manDao(a, 10)
jodi(borok(a, 5)) {
    dekhao("big", a)
}
```

```
=== TOKENS (lexical analysis) ===
LINE:COL TYPE    TEXT
1:1      IDENT   manDao
1:7      LPAREN  (
1:8      IDENT   a
1:9      COMMA   ,
1:11     NUMBER  10
1:13     RPAREN  )
2:1      IDENT   jodi
2:5      LPAREN  (
2:6      IDENT   borok
2:11     LPAREN  (
2:12     IDENT   a
2:13     COMMA   ,
2:15     NUMBER  5
2:16     RPAREN  )
2:17     RPAREN  )
2:19     LBRACE  {
3:5      IDENT   dekhao
3:11     LPAREN  (
3:12     STRING  "big"
3:17     COMMA   ,
3:19     IDENT   a
3:20     RPAREN  )
4:1      RBRACE  }
5:1      END     <end of file>
```

## 7. Phase 2 - Syntax analysis

A recursive-descent parser checks the tokens against this grammar and builds a syntax tree.

```
program   = { statement } ;
statement = ifStmt | whileStmt | call ;
ifStmt    = "Jodi"  "(" expr ")" block [ "nahole" block ] ;
whileStmt = "Ghuro" "(" expr ")" block ;
block     = "{" { statement } "}" ;
call      = IDENT "(" [ expr { "," expr } ] ")" ;
expr      = call | NUMBER | STRING | "true" | "false" | IDENT ;
```

Syntax tree of the sample program (`zyvo prog.zy --ast`):

```
=== SYNTAX TREE (syntax analysis) ===
Call manDao
  Variable a
  Number 10
If (Jodi)
  condition:
    Call borok
      Variable a
      Number 5
  then:
    Call dekhao
      String "big"
      Variable a
```

Syntax errors reported: missing `)` or `}`, `nahole` without `Jodi`, a statement that is not a
function call, missing block after `Jodi` / `Ghuro`, unexpected `{` or `}`.

## 8. Phase 3 - Semantic analysis

The grammar cannot express some rules, so a separate pass checks the tree **before** running it:

* the function exists (with a "did you mean ...?" hint for typing mistakes);
* the number of arguments is correct;
* argument types are correct (number / text / true-false) using static type inference;
* a variable is defined (`ManDao` or `Dhoro`) before it is used;
* the first argument of `ManDao`, `ManPao`, `Baraw`, `Komaw`, `Dhoro` is a variable name;
* conditions of `Jodi` and `Ghuro` are true/false values;
* a command that returns nothing (such as `Dekhao`) is not used as a value;
* obvious mistakes: dividing by the literal `0`, square root of a negative literal.

All semantic errors are collected and shown together; the program is not run if any exist.

## 9. Phase 4 - Execution

A tree-walking interpreter evaluates the checked syntax tree. Values are numbers, text or
true/false. Runtime errors that cannot be found earlier are reported with the line and column:
division or modulus by zero, square root of a negative number, wrong type in a value that came
from user input, missing input, and a loop that runs more than 1,000,000 times (to catch
infinite loops). Text commands count and reverse by character, so Bangla text works.

Output of the sample program: `big 10`

## 10. Error reporting examples

Lexical error:

```
err_lex_unclosed_string.zy:1:8: Lexical error: Unclosed string literal (missing closing ")
  1 | dekhao("Hello)
    |        ^
```

Syntax error:

```
err_syntax_missing_brace.zy:4:1: Syntax error: Missing '}' - the block opened at line 2, column 21 is never closed
```

Semantic errors (both found in one run):

```
err_sem_type_mismatch.zy:1:14: Semantic error: Joggo: argument 1 must be a number, but got a text
  1 | dekhao(joggo("abc", 2))
    |              ^
err_sem_type_mismatch.zy:2:14: Semantic error: Ebong: argument 1 must be a true/false value, but got a number
  2 | dekhao(ebong(1, true))
    |              ^
2 semantic error(s) found - program not run.
```

Runtime error (the first `before` line was printed before the error):

```
before
err_runtime_div_zero.zy:3:8: Runtime error: Division by zero
  3 | dekhao(vaggo(5, z))
    |        ^
```

Exit codes: 0 success, 1 usage/file error, 2 lexical or syntax error, 3 semantic error, 4 runtime error.

## 11. Testing

`tests/` holds 26 programs with expected output, run with `bash run_tests.sh`:

| Group | Count | What it covers |
|---|---|---|
| Valid programs | 10 | all 30 commands, loops, if/else, nesting, input, Bangla text |
| `err_lex_*` | 3 | unexpected character, malformed number, unclosed string |
| `err_syntax_*` | 4 | missing `)`, missing `}`, `nahole` alone, statement that is not a call |
| `err_sem_*` | 7 | unknown function, argument count, types, undefined variable, bad condition, literal zero, no value |
| `err_runtime_*` | 2 | division by zero through a variable, infinite loop |

## 12. Limitations and possible extensions

* It is an interpreter, not a native-code compiler (no code generation).
* Only one value type per variable is tracked statically; variables defined in only one branch
  of a `Jodi` are treated as defined afterwards (a missing value is then caught at runtime).
* No user-defined functions, arrays or file input/output.
* Possible next steps: user-defined functions, a bytecode generator with a small virtual machine,
  arrays, and a `Ghuro` form that counts automatically.

## 13. Conclusion

Zyvo shows how a language can have its own vocabulary and how a processor handles source code
in separate phases: lexical analysis, syntax analysis, semantic analysis and execution. The
30 commands from the proposal are all implemented, including real conditional and loop blocks.
